(()=>{
  'use strict';
  const root=document.getElementById('javo-preview');if(!root)return;
  if(window.lucide)window.lucide.createIcons();
  const menu=root.querySelector('.j-menu'),nav=root.querySelector('.j-nav');menu?.addEventListener('click',()=>{const open=nav.classList.toggle('open');menu.setAttribute('aria-expanded',String(open));});
  const form=root.querySelector('#j-live-form');if(!form)return;
  const details=form.querySelector('#j-live-details'),vehicle=form.querySelector('#j-live-vehicle'),result=form.querySelector('#j-live-result');let ticket=null;
  const steps=[...form.querySelectorAll('[data-step]')],previous=form.querySelector('[data-prev]'),next=form.querySelector('[data-next]'),submit=form.querySelector('[type=submit]');let step=0;
  function showStep(n){
    step=n;steps.forEach((s,i)=>s.hidden=i!==n);
    form.querySelectorAll('.j-form-progress li').forEach((li,i)=>{li.classList.toggle('is-complete',i<n);if(i===n)li.setAttribute('aria-current','step');else li.removeAttribute('aria-current');});
    const label=form.querySelector('.j-step-label');if(label)label.textContent='Step '+(n+1)+' of '+steps.length;
    if(previous)previous.hidden=n===0;if(next)next.hidden=n===steps.length-1;if(steps.length)submit.hidden=n!==steps.length-1;
    if(n===steps.length-1){const summary=form.querySelector('.j-review-summary');summary.textContent=(form.elements.name?.value||'Your application')+' · '+(form.elements.package?.value||'Choose a package')+' · '+form.querySelectorAll('#j-live-vehicles [data-record]').length+' vehicle(s) · '+form.querySelectorAll('#j-live-drivers [data-record]').length+' driver(s)';}
  }
  previous?.addEventListener('click',()=>showStep(Math.max(0,step-1)));
  next?.addEventListener('click',()=>{const invalid=[...steps[step].querySelectorAll('input,select,textarea')].find(i=>!i.disabled&&!i.checkValidity());if(invalid){invalid.reportValidity();return;}showStep(Math.min(steps.length-1,step+1));details.scrollIntoView({behavior:'smooth',block:'start'});});
  form.querySelectorAll('input[type=file]').forEach(input=>input.addEventListener('change',()=>{const status=input.parentElement.querySelector('.j-file-selected');if(status)status.textContent=input.files[0]?input.files[0].name+' · '+(input.files[0].size/1024/1024).toFixed(2)+' MB':'Choose a file · maximum 5 MB';}));
  async function token(){const r=await fetch(JAVO.ajax+'?action=javo_token',{credentials:'same-origin',cache:'no-store'});const j=await r.json();if(!j.success)throw new Error('Could not prepare the form. Please reload.');return j.data;}
  if(JAVO.mode==='live')token().then(t=>ticket=t).catch(e=>result.textContent=e.message);
  vehicle.addEventListener('change',()=>{const ready=['Yes','Getting one'].includes(vehicle.value);details.hidden=!ready;details.disabled=!ready;form.querySelector('#j-live-not-ready').hidden=vehicle.value!=='No';if(steps.length)showStep(0);});
  form.querySelector('#j-live-parish').addEventListener('change',e=>{const region=Object.entries(JAVO.regions).find(([,r])=>r.parishes.includes(e.target.value));form.querySelector('#j-live-office').textContent=region?'Regional office: '+region[1].name+' ('+region[0]+')':'';});
  form.querySelector('#j-live-referred').addEventListener('change',e=>{const fields=form.querySelector('#j-live-referrer'),yes=e.target.value==='yes';fields.hidden=!yes;fields.disabled=!yes;});
  form.querySelectorAll('[data-add]').forEach(b=>b.addEventListener('click',()=>{const kind=b.dataset.add,box=form.querySelector('#j-live-'+kind),rows=box.querySelectorAll('[data-record]'),n=rows.length;if(n>=10)return;const clone=rows[0].cloneNode(true);clone.querySelector('legend').textContent=(kind==='vehicles'?'Vehicle ':'Driver ')+(n+1);clone.querySelectorAll('input').forEach(i=>{i.value='';i.name=i.name.replace('[0]','['+n+']');});box.append(clone);b.disabled=n+1>=10;}));
  form.noValidate=true;
  form.addEventListener('submit',async e=>{e.preventDefault();if(steps.length){const invalidStep=steps.findIndex(s=>[...s.querySelectorAll('input,select,textarea')].some(i=>!i.disabled&&!i.checkValidity()));if(invalidStep>=0)showStep(invalidStep);}if(!form.reportValidity()||JAVO.mode!=='live')return;const button=form.querySelector('[type=submit]');button.disabled=true;result.textContent='Submitting… Please keep this page open.';
    try{if(!ticket)throw new Error('The form is still preparing. Please try again shortly.');const data=new FormData(form);let bytes=0;for(const [,value] of data){if(value instanceof File){if(value.size>5*1024*1024)throw new Error('Each upload must be 5 MB or less.');bytes+=value.size;}}if(bytes>25*1024*1024)throw new Error('Combined uploads must be 25 MB or less.');
      data.set('submission_id',ticket.id);data.set('issued',ticket.issued);data.set('token',ticket.token);
      const response=await fetch(JAVO.ajax,{method:'POST',body:data,credentials:'same-origin'});let j;try{j=await response.json();}catch{throw new Error('The server could not process the upload. Reduce file sizes or contact JAVO.');}if(!j.success)throw new Error(j.data?.message||'Could not submit. Please retry.');result.textContent=j.data.message+' Reference: '+j.data.reference;details.hidden=true;details.disabled=true;vehicle.disabled=true;
    }catch(err){result.textContent=err.message;button.disabled=false;}
  });
})();
