<?php
defined('ABSPATH') || exit;
function javo_activate(){
    global $wpdb;require_once ABSPATH.'wp-admin/includes/upgrade.php';$c=$wpdb->get_charset_collate();
    $schemas=[
    'applications'=>"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n reference varchar(40) NOT NULL,\n submission_key varchar(64) NOT NULL,\n kind varchar(16) NOT NULL,\n name varchar(180) NOT NULL,\n email varchar(254) NOT NULL,\n region varchar(2) NOT NULL,\n service_office varchar(2) NOT NULL,\n member_number varchar(16) DEFAULT NULL,\n status varchar(40) NOT NULL,\n version int(11) NOT NULL DEFAULT 0,\n payload longtext NOT NULL,\n created_at datetime NOT NULL,\n PRIMARY KEY  (id),\n UNIQUE KEY reference (reference),\n UNIQUE KEY submission_key (submission_key),\n UNIQUE KEY member_number (member_number)",
    'sequences'=>"region varchar(2) NOT NULL,\n last_number int(11) NOT NULL DEFAULT 0,\n PRIMARY KEY  (region)",
    'number_history'=>"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n application_id bigint(20) unsigned NOT NULL,\n number varchar(16) NOT NULL,\n created_at datetime NOT NULL,\n PRIMARY KEY  (id),\n UNIQUE KEY number (number),\n KEY application_id (application_id)",
    'documents'=>"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n application_id bigint(20) unsigned NOT NULL,\n label varchar(180) NOT NULL,\n filename varchar(200) NOT NULL,\n mime varchar(80) NOT NULL,\n content longblob NOT NULL,\n created_at datetime NOT NULL,\n PRIMARY KEY  (id),\n KEY application_id (application_id)",
    'events'=>"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n application_id bigint(20) unsigned NOT NULL,\n event_key varchar(64) NOT NULL,\n stage varchar(40) NOT NULL,\n actor bigint(20) unsigned NOT NULL,\n payload longtext NOT NULL,\n created_at datetime NOT NULL,\n PRIMARY KEY  (id),\n UNIQUE KEY event_key (event_key),\n KEY application_id (application_id)",
    'mail'=>"id bigint(20) unsigned NOT NULL AUTO_INCREMENT,\n application_id bigint(20) unsigned NOT NULL,\n event_key varchar(80) NOT NULL,\n recipient varchar(254) NOT NULL,\n subject varchar(250) NOT NULL,\n body longtext NOT NULL,\n documents text NOT NULL,\n state varchar(20) NOT NULL DEFAULT 'queued',\n last_error text DEFAULT NULL,\n attempts int(11) NOT NULL DEFAULT 0,\n updated_at datetime NOT NULL,\n PRIMARY KEY  (id),\n UNIQUE KEY event_key (event_key),\n KEY state (state)"
    ];
    foreach($schemas as $table=>$fields)dbDelta('CREATE TABLE '.javo_table($table)." (\n$fields\n) ENGINE=InnoDB $c;");
    javo_query($wpdb->query('INSERT IGNORE INTO '.javo_table('number_history').' (application_id,number,created_at) SELECT id,member_number,created_at FROM '.javo_table('applications').' WHERE member_number IS NOT NULL'));
    foreach(array_keys(javo_regions()) as $r)javo_query($wpdb->query($wpdb->prepare('INSERT IGNORE INTO '.javo_table('sequences').' (region,last_number) VALUES (%s,%d)',$r,javo_settings()['start_'.$r])));
    add_option('javo_settings',javo_settings(),'','no');
    update_option('javo_db_version','0.2.0',false);
}
function javo_store_document(int $app,string $label,string $filename,string $mime,string $bytes): int {global $wpdb;javo_query($wpdb->insert(javo_table('documents'),['application_id'=>$app,'label'=>$label,'filename'=>sanitize_file_name($filename),'mime'=>$mime,'content'=>$bytes,'created_at'=>current_time('mysql',true)]));return (int)$wpdb->insert_id;}
function javo_read_upload(array $file): array {
    if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK)throw new RuntimeException('An upload did not complete. Please select the file again.');
    if(!is_uploaded_file($file['tmp_name'])||$file['size']>5*1024*1024||$file['size']<1)throw new RuntimeException('Each document must be between 1 byte and 5 MB.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);$ext=strtolower(pathinfo($file['name'],PATHINFO_EXTENSION));
    $allowed=['application/pdf'=>['pdf'],'image/jpeg'=>['jpg','jpeg'],'image/png'=>['png']];
    if(!isset($allowed[$mime])||!in_array($ext,$allowed[$mime],true))throw new RuntimeException('Only genuine PDF, JPG and PNG documents are accepted.');
    if(str_starts_with($mime,'image/')){$size=getimagesize($file['tmp_name']);if(!$size||$size[0]*$size[1]>30000000)throw new RuntimeException('Please use an image below 30 megapixels.');}
    return ['filename'=>sanitize_file_name($file['name']),'mime'=>$mime,'bytes'=>file_get_contents($file['tmp_name'])];
}
function javo_mail(int $app,string $key,string $to,string $subject,string $body,array $docs=[]){global $wpdb;if(!is_email($to))throw new RuntimeException('A valid email address is required.');javo_query($wpdb->insert(javo_table('mail'),['application_id'=>$app,'event_key'=>$key,'recipient'=>$to,'subject'=>$subject,'body'=>$body,"documents"=>wp_json_encode($docs),'state'=>'queued','attempts'=>0,'updated_at'=>current_time('mysql',true)]));}
function javo_send_queue(){
    global $wpdb;$settings=javo_settings();if($settings['mode']!=='live'||!$settings['mail_enabled']||!$settings['privacy_ready']||!$settings['uploads_ready']||!$settings['mail_tested'])return;
    // One mail worker at a time. A crashed worker is never automatically resent.
    $lock='javo_mail_'.md5($wpdb->prefix);if((int)$wpdb->get_var($wpdb->prepare('SELECT GET_LOCK(%s,0)',$lock))!==1)return;
    try{
        $wpdb->query("UPDATE ".javo_table('mail')." SET state='uncertain' WHERE state='sending' AND updated_at < UTC_TIMESTAMP() - INTERVAL 15 MINUTE");
        $rows=$wpdb->get_results("SELECT * FROM ".javo_table('mail')." WHERE state='queued' ORDER BY id LIMIT 5",ARRAY_A);
        foreach($rows as $row){$files=[];$error='';try{
            javo_query($wpdb->update(javo_table('mail'),['state'=>'sending','attempts'=>(int)$row['attempts']+1,'updated_at'=>current_time('mysql',true)],['id'=>$row['id']]));
            foreach(json_decode($row['documents'],true)?:[] as $id){$doc=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.javo_table('documents').' WHERE id=%d AND application_id=%d',$id,$row['application_id']),ARRAY_A);if(!$doc)throw new RuntimeException('Attachment missing.');$path=tempnam(sys_get_temp_dir(),'javo-');if(!$path||file_put_contents($path,$doc['content'])===false)throw new RuntimeException('Cannot prepare attachment.');chmod($path,0600);$files[$doc['filename']]=$path;}
            // WordPress supports named attachments through PHPMailer's hook.
            $attach=function($mailer)use($files){foreach($files as $name=>$path)$mailer->addAttachment($path,$name);};add_action('phpmailer_init',$attach);
            try{$ok=wp_mail($row['recipient'],$row['subject'],$row['body'],['Content-Type: text/plain; charset=UTF-8']);}finally{remove_action('phpmailer_init',$attach);}
            $state=$ok?'accepted':'failed';if(!$ok)$error='The mail transport did not accept this message. Check the mail provider log before retrying.';
        }catch(Throwable $e){$state='failed';$error=javo_text($e->getMessage(),500);}finally{foreach($files as $path)if(is_file($path))unlink($path);}
        $wpdb->update(javo_table('mail'),['state'=>$state,'last_error'=>$error,'updated_at'=>current_time('mysql',true)],['id'=>$row['id']]);}
    }finally{$wpdb->get_var($wpdb->prepare('SELECT RELEASE_LOCK(%s)',$lock));}
}
function javo_download(){
    if(!current_user_can('manage_options'))wp_die('Access denied.',403);$id=absint($_GET['id']??0);check_admin_referer('javo_document_'.$id);global $wpdb;
    $d=$wpdb->get_row($wpdb->prepare('SELECT filename,mime,content FROM '.javo_table('documents').' WHERE id=%d',$id),ARRAY_A);if(!$d)wp_die('Document not found.',404);
    nocache_headers();header('X-Robots-Tag: noindex, nofollow, noarchive');header('X-Content-Type-Options: nosniff');header('Content-Type: '.$d['mime']);header('Content-Disposition: attachment; filename="'.sanitize_file_name($d['filename']).'"');header('Content-Length: '.strlen($d['content']));echo $d['content'];exit;
}

