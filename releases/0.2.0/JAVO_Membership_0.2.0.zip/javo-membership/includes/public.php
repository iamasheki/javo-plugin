<?php
defined('ABSPATH') || exit;
function javo_pages(): array {return require JAVO_DIR.'includes/pages.php';}
function javo_create_pages(){
    $map=(array)get_option('javo_pages',[]);
    foreach(javo_pages() as $key=>$page){if(!empty($map[$key])&&get_post($map[$key]))continue;$content=file_get_contents(JAVO_DIR.'templates/'.$key.'.html');$id=wp_insert_post(['post_type'=>'page','post_status'=>'draft','post_title'=>$page['title'],'post_name'=>$page['slug'],'post_content'=>$content,'post_excerpt'=>$page['description'],'comment_status'=>'closed'],true);if(is_wp_error($id))throw new RuntimeException($id->get_error_message());update_post_meta($id,'_javo_page',$key);$map[$key]=$id;update_option('javo_pages',$map,false);}
}
function javo_refresh_pages(): array {
    $baselines=json_decode(file_get_contents(JAVO_DIR.'includes/template-baselines.json'),true);$result=['updated'=>[],'preserved'=>[]];
    foreach((array)get_option('javo_pages',[]) as $key=>$id){
        $post=get_post($id);if(!$post||!isset(javo_pages()[$key]))continue;
        $new=file_get_contents(JAVO_DIR.'templates/'.$key.'.html');if($post->post_content===$new)continue;
        if(!in_array(hash('sha256',$post->post_content),$baselines[$key]??[],true)){$result['preserved'][]=$key;continue;}
        add_post_meta($id,'_javo_design_backup',['saved_at'=>gmdate('c'),'content'=>$post->post_content]);
        $saved=wp_update_post(['ID'=>$id,'post_content'=>$new],true);if(is_wp_error($saved))throw new RuntimeException($saved->get_error_message());$result['updated'][]=$key;
    }update_option('javo_design_refresh_result',$result,false);return $result;
}
function javo_page_url(string $key): string {$id=get_option('javo_pages',[])[$key]??0;if(!$id)return home_url('/');if(get_post_status($id)!=='publish'&&current_user_can('edit_post',$id))return get_preview_post_link($id);return get_permalink($id);}
function javo_template(string $old): string {if(is_singular('page')&&get_post_meta(get_queried_object_id(),'_javo_page',true)){wp_enqueue_style('javo-site',JAVO_URL.'assets/site.css',[],'0.2.0');wp_enqueue_style('javo-production',JAVO_URL.'assets/production.css',['javo-site'],'0.2.0');wp_enqueue_style('javo-refinements',JAVO_URL.'assets/refinements.css',['javo-production'],'0.2.0');wp_enqueue_script('javo-icons',JAVO_URL.'assets/lucide.min.js',[],'0.468.0',true);wp_enqueue_script('javo-site',JAVO_URL.'assets/site.js',['javo-icons'],'0.2.0',true);wp_localize_script('javo-site','JAVO',['ajax'=>admin_url('admin-ajax.php'),'regions'=>javo_regions(),'mode'=>javo_settings()['mode']]);return JAVO_DIR.'templates/page.php';}return $old;}
function javo_page_content(string $content): string {
    $map=['after'=>'after-registration','licensed'=>'after-licensing','renewals'=>'renewals','tax'=>'tax'];
    $content=preg_replace_callback('/\[\[url:([a-z-]+)\]\]/',fn($m)=>esc_url(javo_page_url($map[$m[1]]??$m[1])),$content);
    $content=preg_replace_callback('/\[\[mascot:(welcome|checklist|documents|reminder)\]\]/',function($m){$url=javo_settings()['mascot_'.$m[1]]??'';return $url?'<img class="j-approved-mascot" src="'.esc_url($url).'" alt="JAVO '.$m[1].' guidance illustration" loading="lazy" width="170" height="230">':'';},$content);
    return str_replace('[[assets]]',esc_url(JAVO_URL.'assets/'),$content);
}
function javo_seo(){
    $id=get_queried_object_id();$key=get_post_meta($id,'_javo_page',true);if(!$key||is_preview()||get_post_status($id)!=='publish')return;$page=javo_pages()[$key]??null;if(!$page)return;
    // Keep one SEO owner. AIOSEO receives the explicit page copy via its filters.
    if(defined('AIOSEO_VERSION')||function_exists('aioseo')){add_filter('aioseo_title',fn($v)=>get_post_meta($id,'_javo_seo_title',true)?:$page['seo']);add_filter('aioseo_description',fn($v)=>get_post_meta($id,'_javo_seo_description',true)?:get_post_field('post_excerpt',$id));return;}
    if(defined('SURERANK_VERSION')||defined('WPSEO_VERSION')||defined('RANK_MATH_VERSION'))return;
    $url=get_permalink($id);$desc=get_post_meta($id,'_javo_seo_description',true)?:get_post_field('post_excerpt',$id);$title=get_post_meta($id,'_javo_seo_title',true)?:$page['seo'];
    echo '<meta name="description" content="'.esc_attr($desc).'">';
    echo '<meta property="og:type" content="website"><meta property="og:title" content="'.esc_attr($title).'"><meta property="og:description" content="'.esc_attr($desc).'"><meta property="og:url" content="'.esc_url($url).'">';
    echo '<meta name="twitter:card" content="summary_large_image"><meta property="og:image" content="'.esc_url(JAVO_URL.'assets/social.jpg').'">';
    $schema=['@context'=>'https://schema.org','@type'=>'Organization','@id'=>home_url('/#organization'),'name'=>'Jamaica Adventure Vehicle Operators (JAVO) Limited','url'=>home_url('/'),'email'=>'info@javojamaica.com','telephone'=>'+1-876-469-6425','areaServed'=>['@type'=>'Country','name'=>'Jamaica'],'logo'=>JAVO_URL.'assets/logo.webp'];
    echo '<script type="application/ld+json">'.wp_json_encode($schema,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script>';
}
add_filter('document_title_parts',function($parts){$key=get_post_meta(get_queried_object_id(),'_javo_page',true);if($key&&isset(javo_pages()[$key])){$parts['title']=get_post_meta(get_queried_object_id(),'_javo_seo_title',true)?:javo_pages()[$key]['seo'];unset($parts['site'],$parts['tagline']);}return $parts;});
add_filter('aioseo_title',function($title){$id=get_queried_object_id();$key=get_post_meta($id,'_javo_page',true);return isset(javo_pages()[$key])?(get_post_meta($id,'_javo_seo_title',true)?:javo_pages()[$key]['seo']):$title;});
add_filter('aioseo_description',function($desc){$id=get_queried_object_id();return get_post_meta($id,'_javo_page',true)?(get_post_meta($id,'_javo_seo_description',true)?:get_post_field('post_excerpt',$id)):$desc;});
add_filter('wp_robots',function($robots){$id=get_queried_object_id();if(get_post_meta($id,'_javo_page',true)&& (is_preview()||get_post_status($id)!=='publish'||get_post_meta($id,'_javo_page',true)==='apply')){$robots['noindex']=true;unset($robots['index']);}return $robots;});
add_filter('wp_sitemaps_posts_query_args',function($args,$type){if($type==='page'){$apply=get_option('javo_pages',[])['apply']??0;if($apply)$args['post__not_in']=array_unique(array_merge($args['post__not_in']??[],[$apply]));}return $args;},10,2);
function javo_public_token(){nocache_headers();$uuid=wp_generate_uuid4();$issued=time();wp_send_json_success(['id'=>$uuid,'issued'=>$issued,'token'=>hash_hmac('sha256',$uuid.'|'.$issued,wp_salt('nonce'))]);}
function javo_submit(){
    try{
        if($_SERVER['REQUEST_METHOD']!=='POST')throw new RuntimeException('Use the application form.');$set=javo_settings();if($set['mode']!=='live'||!$set['privacy_ready']||!$set['uploads_ready']||!$set['mail_tested'])throw new RuntimeException('Online applications are being prepared. Please contact JAVO for assistance.');
        $p=wp_unslash($_POST);$id=javo_text($p['submission_id']??'',64);$issued=(int)($p['issued']??0);$token=(string)($p['token']??'');
        if(!preg_match('/^[a-f0-9-]{36}$/',$id)||!hash_equals(hash_hmac('sha256',$id.'|'.$issued,wp_salt('nonce')),$token)||time()-$issued<3||time()-$issued>7200||!empty($p['website']))throw new RuntimeException('Please reload the page and try again.');
        global $wpdb;$old=$wpdb->get_var($wpdb->prepare('SELECT reference FROM '.javo_table('applications').' WHERE submission_key=%s',$id));if($old)wp_send_json_success(['reference'=>$old,'message'=>'Your submission was already received.']);
        $ip=hash_hmac('sha256',$_SERVER['REMOTE_ADDR']??'unknown',wp_salt('auth'));$limit='javo_rate_'.substr($ip,0,30);$attempts=(int)get_transient($limit);if($attempts>=5)throw new RuntimeException('Too many attempts. Please wait an hour or contact JAVO.');set_transient($limit,$attempts+1,HOUR_IN_SECONDS);
        $kind=($p['kind']??'')==='application'?'application':'enquiry';$name=javo_text($p['name']??'',180);$email=sanitize_email($p['email']??'');$phone=javo_text($p['phone']??'',40);$parish=javo_text($p['parish']??'',50);$region=javo_region($parish);
        if(!$name||!$phone||!is_email($email)||empty($p['privacy']))throw new RuntimeException('Complete your name, phone, email, parish and privacy acknowledgment.');
        if(!in_array($p['vehicle_status']??'',['Yes','Getting one'],true))throw new RuntimeException('Please return when you have a vehicle or are in the process of getting one.');
        $package=javo_text($p['package']??'',50);if(!in_array($package,['Membership Only','Full Service','I need help deciding'],true)||($kind==='application'&&$package==='I need help deciding'))throw new RuntimeException('Choose your membership package.');
        $data=['phone'=>$phone,'parish'=>$parish,'package'=>$package,'vehicle_status'=>javo_text($p['vehicle_status']),'vehicle_type'=>javo_text($p['vehicle_type']??''),'message'=>javo_text($p['message']??''),'referrer_name'=>javo_text($p['referrer_name']??'',180),'referrer_phone'=>javo_text($p['referrer_phone']??'',40),'marketing'=>!empty($p['marketing']),'privacy_version'=>get_post_modified_time('c',true,get_option('javo_pages',[])['privacy']??0),'privacy_accepted_at'=>gmdate('c'),'vehicles'=>[],'drivers'=>[]];$uploads=[];
        $data['referred']=($p['referred']??'no')==='yes';if($data['referred']&&(!$data['referrer_name']||!$data['referrer_phone']))throw new RuntimeException('Provide the referring person’s name and contact number.');
        if($kind==='application'){
            if($email!==sanitize_email($p['email_confirm']??'')||empty($p['terms'])||empty($p['declaration']))throw new RuntimeException('Confirm your email and the application declarations.');
            $data['address']=javo_text($p['address']??'',500);$data['trn']=preg_replace('/[^0-9]/','',$p['trn']??'');$data['signature']=javo_text($p['signature']??'',180);$data['outstanding']=javo_text($p['outstanding']??'');$data['terms_version']=get_post_modified_time('c',true,get_option('javo_pages',[])['terms']??0);
            if(!$data['address']||strlen($data['trn'])!==9||!$data['signature'])throw new RuntimeException('Enter your address, nine-digit TRN and declaration name.');
            foreach(['vehicles'=>['model','year','plate','chassis','engine','owner'],'drivers'=>['name','licence','expiry']] as $list=>$fields){$rows=$p[$list]??[];if(!is_array($rows)||count($rows)<1||count($rows)>10)throw new RuntimeException('Provide 1–10 '.$list.'.');foreach($rows as $row){$clean=[];foreach($fields as $field)$clean[$field]=javo_text($row[$field]??'',150);if(!$clean[$fields[0]])throw new RuntimeException('Complete each '.$list.' entry.');$data[$list][]=$clean;}}
            $required=['passport_photo','driver_licence','registration','fitness','insurance','tcc'];$total=0;
            foreach($_FILES as $label=>$f){if(($f['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE)continue;if(!in_array($label,array_merge($required,['id','address_proof','police_record','lform','additional_documents','payment_proof']),true))throw new RuntimeException('Unrecognised upload field.');$doc=javo_read_upload($f);if($label==='passport_photo'&&!str_starts_with($doc['mime'],'image/'))throw new RuntimeException('Upload your digital passport photo as JPG or PNG.');$total+=strlen($doc['bytes']);$uploads[$label]=$doc;}
            if($total>25*1024*1024)throw new RuntimeException('The combined uploads must be below 25 MB.');if(!isset($uploads['passport_photo']))throw new RuntimeException('Please upload your digital passport-sized photo.');
            foreach($required as $r)if(!isset($uploads[$r])&&!$data['outstanding'])throw new RuntimeException('Upload '.$r.' or explain the outstanding documents.');
            if((count($data['drivers'])>1||count($data['vehicles'])>1)&&!isset($uploads['additional_documents'])&&!$data['outstanding'])throw new RuntimeException('Upload the labelled documents for additional drivers or vehicles, or explain what is outstanding.');
        }
        $reference='JAVO-'.strtoupper(substr(str_replace('-','',wp_generate_uuid4()),0,12));
        javo_transaction(function()use($wpdb,$id,$kind,$name,$email,$region,$data,$reference,$uploads,$set){
            javo_query($wpdb->insert(javo_table('applications'),['reference'=>$reference,'submission_key'=>$id,'kind'=>$kind,'name'=>$name,'email'=>$email,'region'=>$region,'service_office'=>$region,'status'=>'received','payload'=>wp_json_encode($data),'created_at'=>current_time('mysql',true)]));$app=(int)$wpdb->insert_id;
            foreach($uploads as $label=>$d)javo_store_document($app,str_replace('_',' ',$label),$d['filename'],$d['mime'],$d['bytes']);
            javo_query($wpdb->insert(javo_table('events'),['application_id'=>$app,'event_key'=>$id,'stage'=>'received','actor'=>0,'payload'=>wp_json_encode(['kind'=>$kind,'privacy_accepted'=>true]),'created_at'=>current_time('mysql',true)]));
            $body=$kind==='application'?'Thank you for applying for JAVO membership. Allow 5–10 days for review of a complete application. We will email you about missing documents and each recorded application stage. Membership is subject to approval.':'Thank you for your interest in JAVO. Our team aims to contact you within 1–2 business days to discuss your preferred option and next steps.';
            javo_mail($app,$id.'-member',$email,'JAVO '.$kind.' received · '.$reference,'Hi '.$name.",\n\n".$body."\n\nYour reference: ".$reference."\nJAVO | info@javojamaica.com | +1 876 469 6425");
            javo_mail($app,$id.'-staff',$set['email'],'New JAVO '.$kind.' · '.$reference,'A new '.$kind.' is ready for review. Sign in to WordPress to review the record: '.admin_url('admin.php?page=javo&application='.$app));
        });wp_send_json_success(['reference'=>$reference,'message'=>'Thank you. Your '.$kind.' has been received. A confirmation email has been queued.']);
    }catch(Throwable $e){wp_send_json_error(['message'=>$e->getMessage()],400);}
}
