<?php
defined('ABSPATH') || exit;
function javo_correction_form(array $a){
 echo '<details><summary>Correct details before membership approval</summary>';javo_form_start('details');
 echo '<input type="hidden" name="id" value="'.(int)$a['id'].'"><input type="hidden" name="version" value="'.(int)$a['version'].'">';
 javo_field('name','Full legal name',$a['name'],'text',true);javo_field('email','Verified recipient email',$a['email'],'email',true);javo_field('address','Residential address',$a['data']['address']??'');
 foreach($a['data']['vehicles']??[] as $i=>$vehicle){echo '<h3>Vehicle '.($i+1).'</h3>';foreach(['model','year','plate','chassis','engine','owner'] as $k)javo_field('vehicles['.$i.']['.$k.']',ucfirst($k),$vehicle[$k]??'');}
 javo_field('reason','Reason for correction','','text',true);submit_button('Save corrected details','secondary');echo '</form></details>';
}
function javo_correct_details(int $id,array $p){
 global $wpdb;javo_transaction(function()use($p,$id,$wpdb){
  $a=javo_app($id,true);if($a['member_number']||(int)($p['version']??-1)!==(int)$a['version'])throw new RuntimeException('The record changed or has already been approved. Reload it.');
  $name=javo_text($p['name']??'',180);$email=sanitize_email($p['email']??'');$reason=javo_text($p['reason']??'');if(!$name||!is_email($email)||!$reason)throw new RuntimeException('Complete the name, verified email and correction reason.');
  $data=$a['data'];$data['address']=javo_text($p['address']??'',500);foreach($data['vehicles'] as $i=>&$vehicle)foreach(['model','year','plate','chassis','engine','owner'] as $k)$vehicle[$k]=javo_text($p['vehicles'][$i][$k]??'',150);unset($vehicle);
  javo_query($wpdb->update(javo_table('applications'),['name'=>$name,'email'=>$email,'payload'=>wp_json_encode($data),'version'=>$a['version']+1],['id'=>$id]));
  javo_query($wpdb->insert(javo_table('events'),['application_id'=>$id,'event_key'=>wp_generate_uuid4(),'stage'=>'details-corrected','actor'=>get_current_user_id(),'payload'=>wp_json_encode(['reason'=>$reason,'old_name'=>$a['name'],'old_email'=>$a['email'],'old_details'=>$a['data']]),'created_at'=>current_time('mysql',true)]));
 });
}
