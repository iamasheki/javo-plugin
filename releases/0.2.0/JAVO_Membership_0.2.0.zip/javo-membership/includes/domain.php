<?php
defined('ABSPATH') || exit;
function javo_regions(): array {
    return [
        'MB'=>['name'=>'Montego Bay — Western Region','parishes'=>['St. James','Hanover','Trelawny','Westmoreland']],
        'OS'=>['name'=>'Ocho Rios — Northern & Eastern Region','parishes'=>['St. Ann','St. Mary','Portland','St. Catherine','Kingston','St. Andrew','St. Thomas']],
        'SE'=>['name'=>'South Coast Regional Office — St. Elizabeth','parishes'=>['St. Elizabeth','Manchester','Clarendon']]
    ];
}
function javo_region(string $parish): string { foreach(javo_regions() as $code=>$r) if(in_array($parish,$r['parishes'],true)) return $code; throw new RuntimeException('Choose a valid Jamaican parish.'); }
function javo_stages(): array {static $v; return $v ??= array_column(json_decode(file_get_contents(JAVO_DIR.'includes/stages.json'),true),null,'id');}
function javo_settings(): array {$settings=array_merge(['mode'=>'review','email'=>'info@javojamaica.com','registry_ready'=>0,'mail_enabled'=>0,'privacy_ready'=>0,'uploads_ready'=>0,'mail_tested'=>0,'licensing_verified'=>0,'tpdco_wording_ready'=>0,'start_MB'=>1,'start_OS'=>1,'start_SE'=>3,'declaration'=>'','tpdco_wording'=>'Please accept this confirmation of JAVO membership as supporting correspondence for the applicable tourism licensing application. It does not confirm government approval or replace any licence, inspection, insurance or driver requirement.','signatory'=>'Asheki Spooner, Director'],(array)get_option('javo_settings',[]));foreach(['MB'=>1,'OS'=>1,'SE'=>3] as $region=>$floor)$settings['start_'.$region]=max($floor,(int)$settings['start_'.$region]);return $settings;}
function javo_approved_register(): array {return ['Asheki Spooner'=>'SE-001','Alex Brooks'=>'SE-002','Calvin Powell'=>'SE-003','Clover Thomas'=>'MB-001','Michael Vermont'=>'OS-001'];}
function javo_text($value,int $limit=2000): string {return mb_substr(sanitize_textarea_field(is_scalar($value)?(string)$value:''),0,$limit);}
function javo_table(string $name): string {global $wpdb;return $wpdb->prefix.'javo_'.$name;}
function javo_query($result){global $wpdb;if($result===false)throw new RuntimeException('The record could not be saved. Please retry or contact the administrator.');return $result;}
function javo_transaction(callable $f){global $wpdb;javo_query($wpdb->query('START TRANSACTION'));try{$r=$f();javo_query($wpdb->query('COMMIT'));return $r;}catch(Throwable $e){$wpdb->query('ROLLBACK');throw $e;}}
function javo_app(int $id,bool $lock=false): array {global $wpdb;$r=$wpdb->get_row($wpdb->prepare('SELECT * FROM '.javo_table('applications').' WHERE id=%d'.($lock?' FOR UPDATE':''),$id),ARRAY_A);if(!$r)throw new RuntimeException('Application not found.');$r['data']=json_decode($r['payload'],true)?:[];return $r;}
function javo_date(string $v): bool {$d=DateTimeImmutable::createFromFormat('!Y-m-d',$v);return $d && $d->format('Y-m-d')===$v;}
function javo_member_number(string $region,int $number): string {if(!isset(javo_regions()[$region])||$number<1||$number>2147483647)throw new RuntimeException('The regional membership sequence is outside the supported range.');return $region.'-'.str_pad((string)$number,3,'0',STR_PAD_LEFT);}
function javo_vehicle_numbers(string $member,int $count): array {return array_map(fn($n)=>$member.'-'.str_pad((string)$n,2,'0',STR_PAD_LEFT),range(1,$count));}
function javo_fill(string $text,array $values): string {return preg_replace_callback('/\{([a-z_]+)\}/',function($m)use($values){if(!isset($values[$m[1]])||trim((string)$values[$m[1]])==='')throw new RuntimeException('Complete the email field: '.str_replace('_',' ',$m[1]).'.');return (string)$values[$m[1]];},$text);}

