<?php
defined('ABSPATH') || exit;
function javo_progress_summary(array $a){
    global $wpdb;$tracks=[];$stages=javo_stages();
    foreach($wpdb->get_results($wpdb->prepare('SELECT stage,payload,created_at FROM '.javo_table('events').' WHERE application_id=%d ORDER BY id DESC',$a['id']),ARRAY_A) as $row){
        $stage=$stages[$row['stage']]??null;if(!$stage)continue;$fields=json_decode($row['payload'],true)['fields']??[];$subject=$fields['driver_name']??$fields['vehicle_label']??'Member';$key=$stage['group'].'|'.$subject;
        if(!isset($tracks[$key]))$tracks[$key]=[$stage['group'],$subject,$stage['label'],$row['created_at']];
    }
    if(!$tracks)return;echo '<h2>Independent workflow progress</h2><p>Police-record, L-Form and vehicle tracks remain separate. This records staff-verified events; it does not independently verify government approval.</p><table class="widefat striped"><thead><tr><th>Track</th><th>Member / vehicle / driver</th><th>Latest event for this track</th><th>Recorded UTC</th></tr></thead><tbody>';
    foreach($tracks as $values){echo '<tr>';foreach($values as $value)echo '<td>'.esc_html($value).'</td>';echo '</tr>';}echo '</tbody></table>';
}
function javo_record_custody(int $id,array $p){
    global $wpdb;javo_transaction(function()use($id,$p,$wpdb){
        $a=javo_app($id,true);$key=javo_text($p['event_key']??'',64);
        if(!preg_match('/^[a-f0-9-]{36}$/',$key))throw new RuntimeException('Reload the originals form.');
        if($wpdb->get_var($wpdb->prepare('SELECT id FROM '.javo_table('events').' WHERE event_key=%s',$key)))return;
        if((int)($p['version']??-1)!==(int)$a['version'])throw new RuntimeException('The record changed. Reload it before recording custody.');
        $v=[];foreach(['document_label','vehicle_or_driver','custody','custodian','recorded_date','notes'] as $field)$v[$field]=javo_text($p[$field]??'',500);
        if(!$v['document_label']||!$v['custodian']||!javo_date($v['recorded_date'])||!in_array($v['custody'],['with-applicant','received-by-javo','submitted-to-authority','returned-to-member'],true))throw new RuntimeException('Identify the physical original, its custodian, custody status and date.');
        javo_query($wpdb->insert(javo_table('events'),['application_id'=>$id,'event_key'=>$key,'stage'=>'original-custody','actor'=>get_current_user_id(),'payload'=>wp_json_encode($v),'created_at'=>current_time('mysql',true)]));
        javo_query($wpdb->update(javo_table('applications'),['version'=>$a['version']+1],['id'=>$id]));
    });
}
function javo_custody_form(array $a){
    global $wpdb;echo '<h2>Physical originals register</h2><p>Uploaded copies are separate. Record each physical original and every custody change; do not treat an upload as receipt of an original.</p><ul>';
    foreach($wpdb->get_results($wpdb->prepare('SELECT payload,created_at FROM '.javo_table('events').' WHERE application_id=%d AND stage=%s ORDER BY id DESC',$a['id'],'original-custody'),ARRAY_A) as $row){$v=json_decode($row['payload'],true);echo '<li>'.esc_html($v['document_label'].' — '.$v['custody'].' — '.$v['custodian'].' — '.$v['recorded_date'].' — '.$v['vehicle_or_driver']).'</li>';}
    echo '</ul>';javo_form_start('custody');foreach(['id'=>$a['id'],'version'=>$a['version'],'event_key'=>wp_generate_uuid4()] as $name=>$value)echo '<input type="hidden" name="'.esc_attr($name).'" value="'.esc_attr($value).'">';
    javo_field('document_label','Physical original document','','text',true);javo_field('vehicle_or_driver','Related vehicle or driver');javo_field('custodian','Person / office holding the original','','text',true);javo_field('recorded_date','Custody date','','date',true);
    echo '<p><label>Custody status <select name="custody"><option value="with-applicant">With applicant</option><option value="received-by-javo">Received by JAVO</option><option value="submitted-to-authority">Submitted to authority</option><option value="returned-to-member">Returned to member</option></select></label></p>';javo_field('notes','Receipt reference / handover notes');submit_button('Record physical original','secondary');echo '</form>';
}
function javo_record_acknowledgment(int $id,array $p){
    global $wpdb;javo_transaction(function()use($id,$p,$wpdb){$a=javo_app($id,true);$date=javo_text($p['received_date']??'');$method=javo_text($p['method']??'');$notes=javo_text($p['notes']??'');if(!javo_date($date)||!in_array($method,['email-reply','signed-handout'],true)||!$notes)throw new RuntimeException('Record the acknowledgment date, method and evidence reference.');javo_query($wpdb->insert(javo_table('events'),['application_id'=>$id,'event_key'=>wp_generate_uuid4(),'stage'=>'handover-acknowledged','actor'=>get_current_user_id(),'payload'=>wp_json_encode(['received_date'=>$date,'method'=>$method,'evidence'=>$notes]),'created_at'=>current_time('mysql',true)]));javo_query($wpdb->update(javo_table('applications'),['version'=>$a['version']+1],['id'=>$id]));});
}
