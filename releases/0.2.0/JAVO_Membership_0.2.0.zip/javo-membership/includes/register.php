<?php
defined('ABSPATH') || exit;
function javo_reserve_number(int $id,string $number){
    global $wpdb;
    if(preg_match('/^(MB|OS|SE)-([0-9]+)$/',$number,$parts)){
        $pattern='^'.$parts[1].'-[0-9]+$';$numeric=(int)$parts[2];
        $reserved=$wpdb->get_var($wpdb->prepare('SELECT application_id FROM '.javo_table('number_history').' WHERE number REGEXP %s AND CAST(SUBSTRING(number,4) AS UNSIGNED)=%d AND application_id<>%d LIMIT 1',$pattern,$numeric,$id));
        $current=$wpdb->get_var($wpdb->prepare('SELECT id FROM '.javo_table('applications').' WHERE member_number REGEXP %s AND CAST(SUBSTRING(member_number,4) AS UNSIGNED)=%d AND id<>%d LIMIT 1',$pattern,$numeric,$id));
        if($reserved||$current)throw new RuntimeException('This number, including a previously padded form, has already been used by another membership.');
    }
    $owner=$wpdb->get_var($wpdb->prepare('SELECT application_id FROM '.javo_table('number_history').' WHERE number=%s',$number));
    if($owner && (int)$owner!==$id)throw new RuntimeException('This number has already been used by another membership.');
    $other=$wpdb->get_var($wpdb->prepare('SELECT id FROM '.javo_table('applications').' WHERE member_number=%s AND id<>%d',$number,$id));
    if($other)throw new RuntimeException('This number belongs to another membership.');
    if(!$owner)javo_query($wpdb->insert(javo_table('number_history'),['application_id'=>$id,'number'=>$number,'created_at'=>current_time('mysql',true)]));
}
function javo_reconcile_number(int $id,array $p){
    global $wpdb;
    javo_transaction(function()use($id,$p,$wpdb){
        $a=javo_app($id,true);$old=javo_text($p['previous_number']??'',16);$new=javo_text($p['new_number']??'',16);$reason=javo_text($p['reason']??'');
        if(!$a['member_number']||$old!==$a['member_number']||(int)($p['version']??-1)!==(int)$a['version'])throw new RuntimeException('The existing member record changed. Reload and verify the issued number.');
        if(empty($p['reconciled'])||!$reason)throw new RuntimeException('Verify the member register and explain this reconciliation.');
        if(!preg_match('/^(MB|OS|SE)-([0-9]{3,10})$/',$new,$m)||$m[1]!==$a['region']||javo_member_number($m[1],(int)$m[2])!==$new)throw new RuntimeException('Use the original prefecture and a number with a minimum of three digits.');
        // Lock the regional counter before reserving any new identifier.
        $wpdb->get_var($wpdb->prepare('SELECT last_number FROM '.javo_table('sequences').' WHERE region=%s FOR UPDATE',$a['region']));
        javo_reserve_number($id,$old);javo_reserve_number($id,$new);
        javo_query($wpdb->update(javo_table('applications'),['member_number'=>$new,'version'=>$a['version']+1],['id'=>$id]));
        javo_query($wpdb->query($wpdb->prepare('UPDATE '.javo_table('sequences').' SET last_number=GREATEST(last_number,%d) WHERE region=%s',(int)$m[2],$a['region'])));
        javo_query($wpdb->insert(javo_table('events'),['application_id'=>$id,'event_key'=>wp_generate_uuid4(),'stage'=>'number-reconciled','actor'=>get_current_user_id(),'payload'=>wp_json_encode(['previous_number'=>$old,'member_number'=>$new,'reason'=>$reason,'existing_documents_preserved'=>true]),'created_at'=>current_time('mysql',true)]));
    });
}
