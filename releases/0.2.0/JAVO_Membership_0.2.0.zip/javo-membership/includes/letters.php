<?php
defined('ABSPATH') || exit;
require_once JAVO_DIR.'vendor/fpdf.php';
function javo_pdf_text(string $t): string {return iconv('UTF-8','Windows-1252//TRANSLIT',$t);}
class JAVO_PDF extends \JAVO_VENDOR\FPDF {
    public string $letterhead='';
    function Header(){if($this->letterhead)$this->Image($this->letterhead,0,0,210,297,'PNG');$this->SetY(46);}
    function Footer(){}
    function paragraph(string $t){$this->MultiCell(0,4.7,javo_pdf_text($t),0,'L');$this->Ln(2.5);}
    function vehicleTable(array $app){
        $widths=[52,13,35,35,35];$headers=['Motor Vehicle Type','Year','Chassis Number','Engine Number','Registration Number'];
        $heading=function()use($widths,$headers){$this->SetFont('Helvetica','B',8);foreach($headers as $i=>$text)$this->Cell($widths[$i],9,$text,1,0,'L');$this->Ln();$this->SetFont('Helvetica','',8.5);};
        $heading();$numbers=javo_vehicle_numbers($app['member_number'],count($app['data']['vehicles']));
        foreach($app['data']['vehicles'] as $i=>$vehicle){
            $values=[$numbers[$i]."\n".$vehicle['model'],$vehicle['year'],$vehicle['chassis'],$vehicle['engine'],$vehicle['plate']];$height=10;
            foreach($values as $col=>$value){$lines=0;foreach(explode("\n",javo_pdf_text($value)) as $line){$lines+=max(1,(int)ceil($this->GetStringWidth($line)/($widths[$col]-4)))+1;}$height=max($height,$lines*4.2+4);}
            if($this->GetY()+$height>260){$this->AddPage();$heading();}
            $y=$this->GetY();$x=20;$this->SetAutoPageBreak(false);
            foreach($values as $col=>$value){$this->Rect($x,$y,$widths[$col],$height);$this->SetXY($x+1,$y+2);$this->MultiCell($widths[$col]-2,4.2,javo_pdf_text($value),0,'L');$x+=$widths[$col];}
            $this->SetAutoPageBreak(true,33);$this->SetXY(20,$y+$height);
        }$this->Ln(5);$this->SetFont('Helvetica','',10);
    }
}
function javo_letter(array $app,array $v,string $authority='transport-authority'): string {
    if(!in_array($authority,['transport-authority','tpdco'],true))throw new RuntimeException('Choose Transport Authority or TPDCo correspondence.');
    $tourism=$authority==='tpdco';
    $assets=require JAVO_DIR.'includes/letter-assets.php';$files=[];
    try{
        foreach($assets as $key=>$base64){$f=tempnam(sys_get_temp_dir(),'javo-');if(!$f)throw new RuntimeException('Cannot prepare letter artwork.');$files[$key]=$f;$bytes=base64_decode($base64,true);if($bytes===false||file_put_contents($f,$bytes)===false)throw new RuntimeException('Cannot prepare letter artwork.');chmod($f,0600);}
        $p=new JAVO_PDF();$p->letterhead=$files['letterhead'];$p->SetMargins(20,46,20);$p->SetAutoPageBreak(true,33);$p->SetTitle('JAVO membership confirmation - '.($tourism?'TPDCo':'The Transport Authority').' - '.$app['member_number']);$p->AddPage();$p->SetFont('Helvetica','',10);
        $p->paragraph('Date: '.wp_date('F j, Y')."\nMembership number: ".$app['member_number']."\nMembership term: ".$v['membership_start'].' to '.$v['membership_expiry']);
        $p->paragraph(($tourism?'Tourism Product Development Company Limited (TPDCo)':'The Transport Authority')."\n".$v[$tourism?'tpdco_recipient_office':'recipient_office']."\n".$v[$tourism?'tpdco_recipient_address':'recipient_address']);$p->paragraph('Dear Sir/Madam,');
        $p->SetFont('Helvetica','B',10);$p->paragraph($tourism?'Re: Membership Confirmation for Tourism Licensing Application':'Re: Membership Confirmation and Application for Contract Carriage Road License');$p->SetFont('Helvetica','',10);
        $p->paragraph('This is to certify that '.$app['name'].' of '.$app['data']['address'].', '.$app['data']['parish'].' is a member of Jamaica Adventure Vehicle Operators (JAVO) Limited and will be operating as a transportation provider under our company.');
        $p->paragraph($tourism?'The member requests membership confirmation in support of the applicable tourism licensing process for the following vehicle(s):':$app['name'].' wishes to apply for a Contract Carriage Road License for the following vehicle(s), which will be used to carry out tourism-related transportation services on behalf of JAVO:');
        $p->vehicleTable($app);
        if(!$tourism)$p->paragraph(javo_settings()['declaration']);
        $p->paragraph($tourism?javo_settings()['tpdco_wording']:'We provide contract carriage services from cruise ship terminals, airports, hotels, and other key tourist points across Jamaica. We kindly ask that you assist in facilitating the processing of this Contract Carriage License application under our operation.');
        $p->paragraph('If you require any further details, please feel free to contact us.');
        // Reserve the entire signature + 50.8 mm (two inch) seal as one unit.
        if($p->GetY()+59>264)$p->AddPage();$y=$p->GetY();$p->paragraph("Yours sincerely,\n\n\n______________________________\n".$v['signatory']);$p->Image($files['seal'],134,$y,50.8,50.8,'PNG');$p->SetY($y+54);
        return $p->Output('S');
    }finally{foreach($files as $f)if(is_file($f))unlink($f);}
}

