# JAVO Website & Membership — 0.2.0

Installable continuation of the supplied JAVO 0.1.0 review build, using the same `javo-membership` folder and existing database tables. This update keeps the original website structure, application workflow, original 23 status templates plus a missed-appointment template, private-document storage, letterhead and seal. It adds the approved corrections described in CHANGELOG.md.

Requires WordPress 6.5+, PHP 8.1+, MySQL/MariaDB with InnoDB, fileinfo, mbstring, iconv and zlib. Development validation used WordPress 6.8.3, PHP 8.3.28 and MariaDB 11.4. Local fonts, icons, PDFs and images are bundled; no third-party assets are fetched while rendering JAVO pages.

## Install or update

1. Verify a current backup of files and database. Export the installed plugin first if later WordPress-only changes may exist: those changes could not be compared from this workspace.
2. In Plugins → Add Plugin → Upload Plugin, select the versioned ZIP. If JAVO is already installed, use WordPress’s replacement/update flow for the same folder. Do not delete member tables or install a second copy under another folder name.
3. Activate, then open **JAVO membership**. The schema update adds identifier history and mail failure information without deleting existing records. Applications, uploaded documents, events, queue entries, settings and page IDs remain in place.
4. Create missing JAVO draft pages. For old draft-build pages, use **Refresh unchanged JAVO page designs**. It updates only content matching the supplied original template exactly, backs it up and preserves custom edits. Review edited pages manually.
5. Follow MIGRATION.md before publishing pages or enabling submissions/mail. Installation alone does not migrate public URLs, select the live homepage, resolve SEO-plugin conflicts or approve legal policies.

The fresh-install default remains **Review**, with public submissions and automatic sending closed. Upgraded sites must confirm the new privacy, private-upload and mail-delivery checks before opening submissions or dispatching queued mail. Existing queued messages are retained; review them before enabling the worker.

## Membership register and letters

Approved shortened identifiers: Asheki Spooner SE-001; Alex Brooks SE-002; Calvin Powell SE-003; Clover Thomas MB-001; Michael Vermont OS-001. The plugin displays this approved reference but does not create duplicate memberships or infer identities from names. Match each person to the existing application and issued documents before using the reconciliation action. Historical five-/six-digit identifiers stay reserved and documents remain unchanged. Numbers are never recycled, and a servicing-office change does not change the original prefecture or member number.

Minimum digits expand naturally: SE-999 → SE-1000. Default next numbers are SE-004, MB-002 and OS-002, provided no higher numbers have already been used. Reconcile sequence floors against the complete register; higher counters remain higher.

Letter approval requires independently verified recipient offices and addresses for **The Transport Authority** and **Tourism Product Development Company Limited (TPDCo)**. The second recipient is not JTB; legitimate JTB licensing references remain. Both PDFs use the same membership/applicant/vehicle data, original letterhead, vehicle table and 50.8 × 50.8 mm seal beside the signature. Existing authorised signatories are retained. No handwritten signature is fabricated.

The Transport Authority body preserves the supplied source structure. Enter the verified licensing declaration and TRN in settings; the supplied source text is in MIGRATION.md. The TPDCo paragraph is newly prepared recipient-specific wording, clearly labelled as a draft in settings. Staff must approve it before issuance. The original material did not include an approved final TPDCo example.

## Forms, documents and notifications

The short enquiry and full application are separate. The full application covers applicant, vehicle, driver, referral, document, optional payment-proof and declaration fields. Photo, registration, fitness, insurance, driver’s licence and TCC remain in the checklist; missing documents need an explanation. Initial applications can list up to ten vehicles/drivers. Each file is limited to 5 MB and combined uploads to 25 MB, subject to host limits. Images/PDFs are type-checked. These limits do not claim malware scanning or encrypted database storage.

Sensitive uploaded documents are stored in private database records, with administrator capability and a per-document nonce required for download. Physical originals have a separate custody register. Handover acknowledgments are recorded from an email reply or signed printable guide; there is no invented member portal or secure-upload link.

Status updates queue member emails with package-specific next steps. The police appointment email includes date, time, location, attendance instructions, required application/receipt attachments and conditional TRN-password guidance without printing the TRN. Police and L-Form events remain independent in history. Missing attachments prevent sending. Accepted mail means transport acceptance, not confirmed inbox delivery. Failed/uncertain messages require provider-log review before retrying. Intentional letter reissues need an explicit checkbox and reason.

## Validation and scope

See TEST-RESULTS.md for executed checks and their limits. Tests do not establish current government licensing, real applicant inbox delivery, hosting backup restoration or an audit of the inaccessible live WordPress site.

Still needed: approved Bitmoji artwork; current licensing verification and TPDCo wording approval; final renewal/refund/privacy/referral policies; confirmed partners and iKonic destination; live URL/SEO/plugin inventory and production-host delivery checks. Partner placeholders stay hidden and the iKonic section routes enquiries to JAVO rather than an invented URL.

Legacy-member import, post-approval vehicle changes, delegated staff roles, renewals billing, member self-service and payment gateways are outside this update. Original documents are not rewritten during reconciliation. Public application uploads must not be opened before the host-specific checks and legal settings are complete.

## Rollback

Deactivate to stop the plugin presentation and its mail cron event. Data and pages remain; there is no destructive uninstall routine. Restore the prior plugin files from your backup if needed. Page-content backups are stored under `_javo_design_backup`, alongside normal WordPress revisions when available. Use the full backup for a complete database rollback.

## Bundled components

FPDF 1.9 and its original licence; Lucide 0.468.0 and its ISC licence; Google DM Sans and DM Serif Display fonts with SIL Open Font Licences. Generated operator scenes are illustrative and do not establish that the pictured person is actual JAVO staff. Original supplied assets remain for compatibility with edited pages; refreshed templates use the corrected navy-shirt scenes.
