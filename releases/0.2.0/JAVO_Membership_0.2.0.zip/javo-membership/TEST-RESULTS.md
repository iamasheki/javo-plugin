# JAVO 0.2.0 validation

Executed in isolated local WordPress containers, not the live JAVO hosting account.

- WordPress 6.8.3 / PHP 8.3.28 / MariaDB 11.4: plugin activation, schema upgrade and InnoDB tables verified.
- 124 integration assertions passed: all 14 parish mappings; minimum-three-digit numbering; expansion to 1000; approved prefecture floors; vehicle suffixes; independent counters; input/date validation; required receiving addresses; transactional rollback; replay protection; explicit reissue requirement; existing number/document preservation; legacy-number reservations; separate PDF storage/queue attachments; custody and acknowledgment history; all original 23 stage templates; idempotent draft-page creation; safe refresh/backups and preservation of edited pages.
- Two simultaneous approvals received SE-004 and SE-005, with distinct numbers.
- 152 Chromium browser assertions passed at 1440, 1024, 820, 390 and 320 pixels: core pages and the member guide render, one H1, resolved routes/assets, no horizontal overflow, navigation, full four-step form progression, cloned vehicle fields, referral fields, upload feedback/payment-proof control, vehicle-ineligibility gating, grouped white footer headings, compact WhatsApp panel, local imagery, canonical/description output, application noindex and private-download rejection.
- HTTP submission tests passed: enquiry creation, retry returning the same reference, full application with a genuine PNG and missing-document explanation, rejection of disguised PHP upload and invalid tokens.
- Local SMTP sink accepted approval messages with both separately named PDFs and required supporting attachments. Review mode blocked sending; missing attachments failed dispatch and produced a reviewable error. No external mail was sent.
- PDF outputs generated for one and ten vehicles, with authority-specific recipients, vehicle table and retained signature/seal. Branded and black-and-white member guides contain two pages, renewal tracker and acknowledgment.
- Follow-up checks passed for numeric alias protection across different zero padding, custom SEO titles, the new missed-appointment transition and independent workflow-track display.
- PHP syntax and JavaScript syntax checks passed.
- Native WordPress ZIP upload/replacement passed and retained existing applications, legacy-number history and stored documents. Native ZIP installation and activation on a separate clean site passed; default review mode, closed submissions/mail and approved sequence floors were verified.

## Limits

Production SMTP/inbox receipt, existing-host upload/packet limits, malware scanning, backup restoration, installed SEO plugins, live-site code/content comparison, old-page/URL dependency migration, current government licensing evidence and final legal/TPDCo wording were not verified remotely. Bitmoji artwork was not supplied. The ZIP remains a review-mode update until those deployment prerequisites are completed.
