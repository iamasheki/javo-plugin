# JAVO 0.2.0 — continuation of the supplied 0.1.0 review build

- Membership numbers use at least three digits and expand after 999. Separate prefecture sequences start after the approved floors: SE-003, MB-001 and OS-001. Higher recorded counters are never lowered.
- Existing members can be reconciled on the same application record. Old numbers remain reserved and linked in audit history; issued document bytes are not rewritten. Servicing-office changes retain the number.
- Separate Transport Authority and TPDCo PDFs, independent verified office/address fields, existing signatory choices, vehicle tables and the original letterhead and 2-inch seal. Both PDFs attach to the approval email. TPDCo wording is a prepared draft requiring staff approval; current licensing claims require verification.
- Repeat saves with the same event are idempotent. A new letter event for an already-issued membership requires explicit reissue confirmation and a reason. Missing attachments fail dispatch, with a visible failure reason.
- Navy/orange/white design refinements, light headings on navy, readable copy, responsive comparison cards, grouped footer, recognisable WhatsApp icon and compact contact panel.
- Four-step native full application; short enquiry remains separate. Consistent fields, rounded upload cards, progress indicators, referral contact details, payment-proof upload and the approved digital-photo instruction.
- Physical-original custody and final-handover acknowledgment are recorded separately from uploaded copies. Existing independent police/L-Form event history and all 23 workflow stages are retained, with an additional explicit missed-appointment stage.
- Refreshed branded and black-and-white member guides, checkboxes, renewal tracker, passenger-data reminders and acknowledgment of receipt. Dates come from issued documents; no unverified fixed renewal dates are asserted.
- Local fonts and generated operator scenes with navy shirts, using the supplied logo as the image-edit reference. Approved Bitmoji slots are available; the actual Bitmoji artwork was not supplied.
- AIOSEO filters retained; fallback metadata, canonical through WordPress, noindex application/preview safeguards and native sitemap exclusion for the application form. Refresh unchanged draft-build pages safely; customised pages stay intact. Published homepage assignment is an explicit administrator action.

No live-site plugins, existing pages, public URLs, SEO settings or member records were changed remotely. See MIGRATION.md for deployment and remaining decisions.
