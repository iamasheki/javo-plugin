# JAVO SEO and page launch checklist

The 18 supplied pages retain unique titles, excerpts/descriptions and one primary heading. Public navigation uses real page links, local assets have descriptive alt text, and official resources are distinguished from JAVO membership/support services. Do not invent ratings, addresses, endorsements or agency certification markup.

AIOSEO is the intended single SEO owner. Its title/description filters are retained. When no supported SEO plugin is active, JAVO supplies description, social previews and Organization markup; WordPress supplies the canonical. Native previews and the full application page receive noindex safeguards; the native WordPress sitemap excludes the application form. Private records/files are not public posts or Media Library URLs; document responses include noindex headers and require administrator capability plus a document nonce.

Inspect the actual installed SEO versions and retained metadata before disabling duplicates. Historical review-build notes mentioned AIOSEO and SureRank together; that is not a current inventory. Eleven plugins were reported deactivated in the project conversation, but their current state could not be inspected from this workspace. No live plugin settings were changed here.

Before publication:

1. Inventory current page IDs, URLs, incoming links, forms, menus and template dependencies; retain established slugs where appropriate.
2. Review and publish approved replacements, then explicitly assign the JAVO homepage and update theme/Elementor navigation outside JAVO’s own template.
3. Configure individual 301 mappings for changed URLs. Check dependencies before moving obsolete pages to recoverable Trash. No guessed redirects or bulk deletions are included.
4. Confirm one canonical, title, description, social-preview set and appropriate schema owner per public page. Check AIOSEO’s sitemap/robots configuration, excluding draft/private/application/confirmation routes.
5. Verify the live XML sitemap, robots, mobile layouts, internal links, PDF downloads, redirects and cache exclusions for admin, authenticated requests and form POSTs.
6. Use the existing verified Search Console property for sitemap submission and monitoring. No Search Console ownership or submissions were performed here.
7. Verify current official licensing/tax requirements before publishing time-sensitive statements. Updated guidance uses actual document expiry dates instead of unverified fixed-cycle claims.

See MIGRATION.md for the full register, policy, imagery, mail and page-deployment requirements. Installation alone does not complete live-site migration or SEO configuration.
