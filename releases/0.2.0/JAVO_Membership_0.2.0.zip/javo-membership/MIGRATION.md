# Installation is separate from live-site migration

This ZIP was built from the uploaded review build and the approved correction list. No connector or credentials for the installed WordPress site were available, so later WordPress-only code/content and the current status of the eleven previously reported deactivated plugins could not be inspected. Export the current installed plugin, database and URL inventory before replacing files. Preserve later changes rather than assuming the uploaded build is the newest deployed source.

## Register and correspondence

- Match the five approved named members to existing records and issued letters. Use **Reconcile an existing member number** on that record; confirm the old identifier and evidence. Do not create a new application to renumber a member.
- Review the historical identifier reservations and complete register. Set each prefecture floor to the highest number already used. Defaults protect SE-001–003, MB-001 and OS-001; they do not prove the rest of the register is complete. Old counter values are never lowered automatically.
- Verify the current company licensing claims and TRN before enabling issuance. The supplied Transport Authority source states:

  > JAVO is officially licensed and recognized by the Jamaica Tourist Board (JTB) and the Tourism Product Development Company (TPDCo).
  > Our Taxpayer Registration Number (TRN) is 003588696.

  Enter that declaration only after verifying it remains accurate. The plugin does not assert that verification has happened.
- Review the draft TPDCo-specific paragraph in settings. Its recipient and separate-PDF requirement are approved; the final wording is not represented as previously approved. Verify each receiving office/address, membership dates, vehicle details and authorised signatory before issuing.
- Install authenticated mail transport, test actual JAVO/applicant receipt and both named PDFs on the production host, then confirm **mail delivery tested**. Configure reliable hosting cron. Inspect retained queued/failed/uncertain messages before enabling sending.
- Test private uploads and downloads on the host, including non-administrator/invalid-nonce rejection, file and total limits, database packet limits and backup protection. Confirm **private uploads tested** only after these pass. Uploads are type-checked but not malware-scanned or encrypted by this plugin.

## Website and pages

1. Create missing draft pages. Use **Refresh unchanged JAVO page designs** for original unchanged template content. Edited pages are listed as preserved; review and merge those manually. Body-content backups remain on each refreshed page.
2. Review all pages on mobile and desktop. Verify current legal text, contact details, official requirements and document expiry dates. Fixed March 31/2026–27 claims were removed from the updated guidance rather than treated as newly verified facts.
3. Supply the approved Bitmoji artwork through WordPress Media and configure welcome/checklist/documents/reminder URLs in JAVO settings. Empty slots remain empty; no replacement identity was invented. The supplied logo and newly generated navy-shirt operator scenes are bundled.
4. Partners remain a hidden homepage section until actual approved partners/assets are supplied. The iKonic section remains on the homepage with a JAVO contact route until its destination is confirmed.
5. Publish approved public pages when ready. Use **Use the published JAVO homepage** to assign the reviewed home page. The JAVO template’s header/footer links use the actual page IDs; update any theme/Elementor menus and site-wide links outside these templates separately.
6. Inventory old URLs, incoming links, forms/entries, shortcode/template dependencies and any WooCommerce/order dependencies. Prefer keeping established slugs; otherwise map each old URL to its relevant replacement and configure reviewed 301 redirects with the existing redirect/SEO system. No blanket redirect or guessed mapping is bundled.
7. Replace obsolete pages using recoverable WordPress Trash only after dependency checks and testing replacements/redirects. Leave still-used Astra/Elementor components and records intact. Inspect current plugin status before any further cleanup; no remote deactivation occurred in this task.

## SEO

AIOSEO remains the intended single SEO owner. Inspect installed plugins and existing metadata before disabling a duplicate system. Retain/export useful metadata first. Verify one title, description, canonical, social-preview set and appropriate schema owner per public page, XML sitemap, robots and redirects. Configure AIOSEO to exclude application/confirmation/private routes and draft pages from its sitemap and indexing. The plugin supplies native WordPress safeguards, but AIOSEO’s actual installed version/settings were not available for verification.

Confirm the new homepage and published pages in the live sitemap; keep previews/private records out. Verify Search Console ownership using the existing property before submission. No live SEO plugin settings, redirects, sitemap submissions or Search Console properties were changed by this ZIP.

## Decisions still outstanding

Membership renewal cycle; final refund/privacy/retention terms; referral payout conditions; approved Bitmoji files; confirmed partners; iKonic destination; current company licensing evidence; final TPDCo wording. Bracketed legal drafts remain drafts. Keep public submissions and automatic mail closed until the site-specific legal, upload and email tests are complete.
