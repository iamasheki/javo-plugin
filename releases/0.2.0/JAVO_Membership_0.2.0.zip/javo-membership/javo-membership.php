<?php
/**
 * Plugin Name: JAVO Website & Membership
 * Description: JAVO website, enquiries, applications, private documents, regional numbers and membership correspondence.
 * Version: 0.2.0
 * Requires at least: 6.5
 * Requires PHP: 8.1
 * Author: JAVO
 * License: GPL-2.0-or-later
 */
defined('ABSPATH') || exit;
define('JAVO_DIR', plugin_dir_path(__FILE__));
define('JAVO_URL', plugin_dir_url(__FILE__));
require_once JAVO_DIR.'includes/domain.php';
require_once JAVO_DIR.'includes/store.php';
require_once JAVO_DIR.'includes/register.php';
require_once JAVO_DIR.'includes/custody.php';
require_once JAVO_DIR.'includes/letters.php';
require_once JAVO_DIR.'includes/public.php';
require_once JAVO_DIR.'includes/admin.php';
require_once JAVO_DIR.'includes/corrections.php';
add_action('admin_init',function(){if(current_user_can('manage_options')&&get_option('javo_db_version')!=='0.2.0')javo_activate();});
register_activation_hook(__FILE__, 'javo_activate');
register_deactivation_hook(__FILE__, function(){ wp_clear_scheduled_hook('javo_mail_tick'); });
add_action('javo_mail_tick', 'javo_send_queue');
add_filter('cron_schedules', function($s){ $s['javo_minute']=['interval'=>60,'display'=>'JAVO email queue']; return $s; });
add_action('init', function(){if(!wp_next_scheduled('javo_mail_tick')) wp_schedule_event(time()+60,'javo_minute','javo_mail_tick');});
add_action('admin_menu','javo_admin_menu');
add_action('admin_post_javo_action','javo_admin_action');
add_action('admin_post_javo_document','javo_download');
add_action('wp_ajax_javo_submit','javo_submit');
add_action('wp_ajax_nopriv_javo_submit','javo_submit');
add_action('wp_ajax_javo_token','javo_public_token');
add_action('wp_ajax_nopriv_javo_token','javo_public_token');
add_filter('template_include','javo_template',99);
add_action('wp_head','javo_seo',1);
add_action('wp_enqueue_scripts',function(){if(is_singular('page')&&get_post_meta(get_queried_object_id(),'_javo_page',true))wp_enqueue_script('javo-icons',JAVO_URL.'assets/lucide.min.js',[],'0.468.0',true);});

